public class Pessoa {
    private String nome;
    private int idade;
    private Endereco endereco;

    public Pessoa(String nome, int idade, Endereco endereco) {
        this.nome = nome;
        this.idade = idade;
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Endereço: " + endereco.getRua() + "- " + endereco.getNumero());
    }

    public static void main(String[] args) {
        Endereco e1 = new Endereco("Rua São Pedro", 25);
        Endereco e2 = new Endereco("Avenida Perimentral", 30);

        Pessoa p1 = new Pessoa("Bia", 22, e1);
        Pessoa p2 = new Pessoa("Bruna", 25, e2);

        p1.mostrarDados();
        p2.mostrarDados();
    }
}